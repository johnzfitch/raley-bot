# CLAUDE.md

## Project Identity

**Raley** — a grocery shopping assistant named after an inspiring person, not the store chain. Wraps a grocery store's web API with intelligent product selection, automatic coupon management, price tracking, and MCP server integration for AI agents.

## Quick Context

This is a Python 3.11+ project using `uv` for package management. The HTTP client shells out to `curl` (not requests/httpx) because the store API uses F5 BIG-IP TLS fingerprinting that blocks Python HTTP libraries. The MCP server runs over stdio for Claude Desktop integration.

## Commands

```bash
# Setup
uv venv && source .venv/bin/activate
uv pip install -e .

# Run
raley login                    # Browser-based auth
raley login --file cookies.json  # Manual cookie import
raley status                   # Session health
raley search "organic milk"    # CLI product search
raley offers                   # List coupons
raley clip-all                 # Clip all unclipped coupons
raley history                  # Previously purchased
raley orders                   # Order history
raley points                   # Loyalty points

# MCP server
raley-mcp                     # Starts stdio MCP server

# Development
pytest                         # Run tests
uv pip install -e ".[dev]"     # Install dev deps
```

## Documentation Map

| Document | Purpose |
|----------|---------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design, module dependency graph, data flow diagrams, database schema, HTTP client rationale, reasoning engine scoring, known gaps |
| [AUDIT.md](AUDIT.md) | Dead code inventory, security fixes applied, disjointed systems analysis, removed functions list |
| [PR.md](PR.md) | v0.3.0 PR description with code review prompt |
| [README.md](README.md) | User-facing documentation, installation, CLI usage, MCP setup |

## Module Guide

### Core Pipeline

| Module | Role | Key Functions |
|--------|------|---------------|
| `api.py` | HTTP client (curl subprocess) | `search_products()`, `add_to_cart()`, `get_cart()`, `get_offers()`, `clip_offer()`, `get_orders()` |
| `mcp_server.py` | MCP tool dispatch (9 tools) | `handle_search()`, `handle_add()`, `handle_plan()`, `handle_offers()` |
| `cli.py` | Click CLI with Rich tables | `login`, `status`, `search`, `offers`, `clip-all`, `history`, `orders`, `points` |

### Intelligence Layer

| Module | Role | Key Functions |
|--------|------|---------------|
| `reasoning.py` | Heuristic product scoring (not ML) | `evaluate_options()` → Decision, `get_purchase_frequency()` → PurchaseFrequency |
| `unit_pricing.py` | Normalize $/oz, $/lb, $/unit, $/ml | `calculate_unit_prices()` → UnitPrice, `compare_value()`, `best_value_from_list()` |
| `db.py` | SQLite price history tracking | `sync_products_from_search()`, `is_good_deal()`, `get_product_with_history()` |
| `preferences.py` | User preference loading | `load_preferences()` → Preferences (with `.general.prefer_organic`, `.preferred_brand()`) |

### Session Management

| Module | Role | Key Functions |
|--------|------|---------------|
| `auth.py` | Browser login via Helium/Selenium | `interactive_login()`, `check_auth_status()` |
| `cookies.py` | Cookie persistence and validation | `import_and_save()`, `validate_cookies()`, `check_cookie_expiry()` |
| `cart_builder.py` | Grocery list parsing + agent API | `parse_grocery_list()`, `find_best_product()`, `quick_add()` |

## Architecture Invariants

These are constraints that must be maintained across all changes:

1. **Curl-only HTTP**: Never use `requests`, `httpx`, `aiohttp`, or `rnet` for store API calls. The F5 bot detection will block them. All HTTP goes through `CurlClient._run_curl()` which uses `subprocess.run(["curl", ...])`.

2. **Single cookie path**: All modules must use `~/.config/raley-assistant/cookies.json`. Do not introduce alternative paths. The previous split-brain between `~/raleys-cookie.json` and the canonical path caused silent failures.

3. **No secrets in plaintext**: Cookie values, session tokens, and API responses containing auth data must never appear in logs, MCP responses, or committed files. The `auth` MCP tool returns session status without cookie values.

4. **Read tools don't write**: Search, cart view, order history, and price check are read-only. They may sync to the local SQLite DB (append-only price observations), but must not modify cart state, clip coupons, or make any destructive API calls. This was violated in v0.2.0 (search was silently clipping coupons) and fixed in v0.3.0.

5. **File permissions**: Any file containing session tokens or user-specific data must be written with `0o600` permissions. Use `os.open()` with explicit mode or `Path.touch(mode=0o600)`.

6. **URL encoding**: All query parameters must go through `urllib.parse.urlencode()`. Never build query strings with f-strings or string concatenation.

7. **Cookie sanitization**: Cookie values must have `\n`, `\r`, and `\x00` stripped before being passed to curl headers. See `_sanitize_cookie_value()` in `api.py`.

## Data Locations

```
~/.config/raley-assistant/
├── cookies.json          # Session tokens (0600)
└── preferences.json      # Shopping preferences

~/.local/share/raley-assistant/
├── raley.db              # SQLite price history
├── cart-*.json           # Saved cart snapshots (0600)
├── orders-*.json         # Saved order history (0600)
├── offers-*.json         # Saved coupon lists (0600)
└── grocery-plan-*.json   # Saved grocery plans (0600)
```

## MCP Tool Contract

Each MCP tool returns a JSON string. Error responses use `{"error": "message"}`. Success responses vary by tool but always include the essential fields listed below.

| Tool | Required Response Fields | Side Effects |
|------|------------------------|--------------|
| `search` | `sku`, `name`, `price`, `cents` | Syncs to price DB |
| `add` | `ok`, `sku`, `qty` | Adds to cart |
| `remove` | `ok`, `sku` | Removes from cart |
| `cart` | `items`, `count`, `total` | None |
| `offers` | Varies by action | `clip_all`: clips coupons; `sync`: writes to DB |
| `plan` | `items`, `total` | None (planning only) |
| `price` | Varies | None |
| `orders` | `orders`, `count` | None |
| `auth` | `authenticated`, `message` | None |

## Known Issues & TODOs

See [ARCHITECTURE.md § Known Gaps](ARCHITECTURE.md#known-gaps--todos) for the full list. Key items:

1. **Preferences → Reasoning wiring**: `preferences.py` exists and loads correctly but `mcp_server.py` always passes `prefer_organic=False` to `evaluate_options()`. Need to load preferences at server startup and pass `prefs.general.prefer_organic`.

2. **`should_buy_this_trip()` unused**: Implemented in `reasoning.py`, needs order history integration.

3. **`flask` phantom dependency**: In `pyproject.toml` but never imported. Remove unless a web UI is planned.

4. **No tests**: `tests/` is empty. Priority test targets: `unit_pricing.py` (pure functions, easy to test), `reasoning.py` (scoring logic), `cart_builder.py` (list parsing), `db.py` (SQLite operations).

5. **CLI missing `search` command**: Product search only available through MCP. Add `raley search <query>` to CLI.

## Code Style

- Python 3.11+ type hints throughout (use `X | None` not `Optional[X]` in new code)
- Dataclasses for structured data, not dicts
- No f-string query params in URLs
- Keep MCP tool responses compact — truncate names to 40 chars, use cents not dollars internally
- Rate limit bulk operations: 200ms between requests, 500ms every 10th

## Testing Strategy

When adding tests:
- `unit_pricing.py` and `reasoning.py` are pure functions — unit test directly
- `cart_builder.py` parsing is regex-based — test edge cases (quantities with units, hyphens, commas, empty lines)
- `db.py` — use `:memory:` SQLite for test isolation
- `api.py` — mock `subprocess.run` return values, test JSON parsing and error handling
- `mcp_server.py` — test handler functions directly (they're async, use `asyncio.run()`)
