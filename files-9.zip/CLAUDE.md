# CLAUDE.md

## Project Identity

**Raley** — a grocery shopping assistant named after an inspiring person, not the store chain. Wraps a grocery store's web API with intelligent product selection, automatic coupon management, price tracking, and MCP server integration for AI agents.

**V2c — Final** — security hardened + intelligence layer + tests. Best of V2a and V2b.

## Commands

```bash
# Setup
uv venv && source .venv/bin/activate
uv pip install -e ".[dev]"

# Run
raley login                     # Browser-based auth
raley login --file cookies.json # Manual cookie import
raley status                    # Session health
raley search "organic milk"     # CLI product search
raley offers                    # List coupons
raley clip-all                  # Clip all unclipped coupons
raley history                   # Previously purchased
raley orders                    # Order history
raley points                    # Loyalty points

# MCP server
raley-mcp                       # Starts stdio MCP server (9 tools)

# Tests
pytest                           # 56 tests, ~0.2s
pytest -v                        # Verbose
pytest tests/test_reasoning.py   # Single module
```

## Documentation Map

| Document | Purpose |
|----------|---------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design, dependency graph, data flow, DB schema, HTTP client rationale, reasoning engine scoring, known gaps |
| [AUDIT.md](AUDIT.md) | Dead code inventory, security fixes applied, disjointed systems analysis |
| [PR.md](PR.md) | v0.3.0 PR description with code review prompt |
| [README.md](README.md) | User-facing docs, install, CLI usage, MCP setup |

## Module Guide

### Core Pipeline

| Module | Role | Key Exports |
|--------|------|-------------|
| `api.py` | HTTP client (curl subprocess) | `search_products()`, `add_to_cart()`, `get_cart()`, `get_offers()`, `clip_offer()`, `get_orders()` |
| `mcp_server.py` | MCP tool dispatch (9 tools) | `handle_search()`, `handle_add()`, `handle_plan()`, `handle_offers()`, `handle_price_check()` |
| `cli.py` | Click CLI with Rich tables | `login`, `status`, `search`, `offers`, `clip-all`, `history`, `orders`, `points` |

### Intelligence Layer

| Module | Role | Key Exports |
|--------|------|-------------|
| `reasoning.py` | Heuristic product scoring (not ML) | `evaluate_options()` → Decision, `get_purchase_frequency()` → PurchaseFrequency |
| `unit_pricing.py` | Normalize $/oz, $/lb, $/unit, $/ml | `calculate_unit_prices()` → UnitPrice, `compare_value()`, `best_value_from_list()` |
| `db.py` | SQLite price history tracking | `sync_products_from_search()`, `is_good_deal()`, `get_product_with_history()` |
| `preferences.py` | User preference loading | `load_preferences()` → Preferences (`.general.prefer_organic`, `.preferred_brand()`) |

### Session Management

| Module | Role | Key Exports |
|--------|------|-------------|
| `auth.py` | Browser login via Helium/Selenium | `interactive_login()`, `check_auth_status()` |
| `cookies.py` | Cookie persistence and validation | `import_and_save()`, `validate_cookies()`, `check_cookie_expiry()` |
| `cart_builder.py` | Grocery list parsing + agent API | `parse_grocery_list()`, `find_best_product()`, `quick_add()` |

## Architecture Invariants

These must be maintained across all changes:

1. **Curl-only HTTP**: Never use `requests`, `httpx`, `aiohttp`, or `rnet`. F5 blocks them. All HTTP through `CurlClient._run_curl()` via `subprocess.run(["curl", ...])`.
2. **Single cookie path**: `~/.config/raley-assistant/cookies.json`. No alternatives.
3. **No secrets in plaintext**: Cookie values never in logs, MCP responses, or commits.
4. **Read tools don't write**: Search, cart view, orders are read-only. DB price sync (append-only) is the sole exception.
5. **File permissions**: `0o600` on all files containing session tokens.
6. **URL encoding**: All query params through `urllib.parse.urlencode()`. No f-string URLs.
7. **Cookie sanitization**: Strip `\n`, `\r`, `\x00` before passing to curl headers.

## Data Locations

```
~/.config/raley-assistant/
├── cookies.json          # Session tokens (0600)
└── preferences.json      # Shopping preferences

~/.local/share/raley-assistant/
├── raley.db              # SQLite price history
└── *.json                # Saved results (0600)
```

## MCP Tool Contract

| Tool | Side Effects | Key Fields |
|------|-------------|------------|
| `search` | Syncs to price DB | `sku`, `name`, `price`, `cents` |
| `add` | Adds to cart | `ok`, `sku`, `qty` |
| `remove` | Removes from cart | `ok`, `sku` |
| `cart` | None | `items`, `count`, `total` |
| `offers` | `clip_all`: clips coupons | varies by action |
| `plan` | None (planning only) | `items`, `total` |
| `price` | None | deal analysis, history |
| `orders` | None | `orders`, `count` |
| `auth` | None | `authenticated`, `message` |

## Testing

56 tests covering pure-function modules. No network calls, no mock complexity.

| File | Module | Tests |
|------|--------|-------|
| `test_reasoning.py` | reasoning.py | Scoring, brand match, frequency classification |
| `test_unit_pricing.py` | unit_pricing.py | Extraction, normalization, comparison |
| `test_db.py` | db.py | Sync, dedup, deal detection (`:memory:` SQLite) |
| `test_cart_builder.py` | cart_builder.py | Grocery list parsing edge cases |
| `test_preferences.py` | preferences.py | Loading, defaults, error handling |

To add tests for `api.py` or `mcp_server.py`: mock `subprocess.run` return values.

## Code Style

- Python 3.11+ type hints (`X | None` not `Optional[X]` in new code)
- `datetime.now(timezone.utc)` not `datetime.utcnow()` (deprecated)
- Dataclasses for structured data, not dicts
- No f-string query params in URLs
- Rate limit bulk operations: 200ms between requests, 500ms every 10th

## Known Issues

See [ARCHITECTURE.md § Known Gaps](ARCHITECTURE.md#known-gaps--todos) for full list. Summary:

1. `should_buy_this_trip()` in reasoning.py — implemented, unused, needs order history
2. No tests for `api.py` / `mcp_server.py` (need subprocess mocking)
3. CLI `clip_all` vs MCP `clip_all` have different rate limiting — should consolidate
